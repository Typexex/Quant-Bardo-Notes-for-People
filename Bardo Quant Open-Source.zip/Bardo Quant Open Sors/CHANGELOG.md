# Changelog

All notable changes to BardoQuant will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2025-01-09

### Added

#### Post-Quantum Cryptography
- **CRYSTALS-Kyber768** KEM (NIST Post-Quantum Cryptography standard)
- NIST Security Level 3 (192-bit equivalent)
- Quantum-computer resistant protection
- Forward secrecy through ephemeral Kyber keys
- KEM encapsulation and decapsulation for secure key exchange

#### Enhanced Key Derivation
- HKDF-Extract with Kyber shared secret
- Multi-round key derivation (3-5 rounds of HMAC-SHA512)
- Independent key derivation for AES, ChaCha20, and quantum layers
- PBKDF2 with 300,000 iterations for additional key strengthening
- Enhanced entropy generation from system parameters

#### Advanced Security Features
- Timing attack protection with constant-time comparison
- Enhanced quantum layer with 16 rounds of SHA-512
- Noise injection (10-15% of data size) for traffic analysis resistance
- Multiple key systems for defense in depth
- Decoy checksums for stealth
- HMAC-SHA512 integrity verification

#### Configuration
- Configurable PBKDF2 iterations
- Configurable quantum layer rounds
- Customizable noise percentage
- Debug logging control
- Custom logger interface support

#### Platform Independence
- Removed Android-specific dependencies
- Universal Kotlin implementation
- Works on any JVM platform (Android, desktop, server)
- Standard Java Base64 encoding
- Pluggable logging system

### Changed

#### Breaking Changes
- Package renamed from `com.example.notepad` to `io.github.bardoquant`
- Logger interface replaces Android Log
- Configuration moved to `BardoQuantConfig` object
- Removed dependency on `AppStrings` (custom exception messages)

#### Improvements
- Complete refactoring for open-source release
- Professional code structure and organization
- Comprehensive documentation
- Better error handling and reporting
- Cleaner API design

#### Backward Compatibility
- Full support for decrypting v1.0 encrypted data
- Full support for decrypting v1.1 encrypted data
- Automatic version detection
- Legacy format support maintained

### Removed
- Android-specific logging (`android.util.Log`)
- Android Base64 (`android.util.Base64`)
- Application-specific string resources
- Hardcoded application identifiers

### Security

#### Cryptographic Primitives
- AES-256-GCM (authenticated encryption)
- ChaCha20 (stream cipher)
- CRYSTALS-Kyber768 (post-quantum KEM)
- HKDF-SHA512 (key derivation)
- PBKDF2-HMAC-SHA256 (key strengthening)
- SHA-512 (quantum layer, 16 rounds)
- HMAC-SHA512 (integrity verification)

#### Protection Against
- Quantum computer attacks (Shor's algorithm)
- Brute-force attacks
- Timing attacks
- Side-channel attacks
- Known-plaintext attacks
- Chosen-plaintext attacks
- Replay attacks

### Documentation
- Comprehensive README.md with examples
- Security policy (SECURITY.md)
- Contributing guidelines (CONTRIBUTING.md)
- MIT License
- API documentation with KDoc
- Architecture documentation
- Performance benchmarks

### Dependencies
- Kotlin 1.9.20
- Bouncy Castle 1.77 (PQC provider)
- Gson 2.10.1
- Kotlinx Coroutines 1.7.3

### Testing
- Unit test structure
- Test examples
- Encryption/decryption tests
- Version compatibility tests

## [1.1.0] - 2024-12-15

### Added
- Optimized quantum layer (8 rounds instead of 16)
- Simplified obfuscation (4 rounds instead of 7)
- Performance improvements for mobile devices
- Released in Bardo Notes for People 1.1 Beta

### Changed
- Reduced computational overhead
- Faster encryption/decryption on mobile
- Maintained security level for typical use cases

### Notes
- Legacy version, maintained for backward compatibility only
- Not recommended for new implementations

## [1.0.0] - 2024-11-01

### Added
- Initial release of BardoQuantum Encryption
- Multi-layer encryption (AES-256-GCM + ChaCha20)
- Dynamic obfuscation (7 rounds)
- Quantum-resistant layer (16 rounds SHA-512)
- Noise injection
- HMAC-SHA512 checksums
- Released in Bardo Notes for People 1.0

### Security
- AES-256-GCM encryption
- ChaCha20 secondary encryption
- SHA-512 quantum protection layer
- PBKDF2 key derivation
- Noise injection for traffic analysis resistance

### Notes
- Legacy version, maintained for backward compatibility only
- Not recommended for new implementations
- Does not include post-quantum KEM

## [Unreleased]

### Planned Features
- Stream encryption support
- Key rotation mechanisms
- Additional PQC algorithms (Dilithium, SPHINCS+)
- Performance optimizations
- Hardware security module (HSM) integration
- Mobile-specific optimizations
- Async encryption APIs

### Under Consideration
- Support for file encryption (not just strings)
- Compression before encryption
- Multi-recipient encryption
- Key escrow mechanisms
- Integration with key management systems

---

## Version History Summary

| Version | Release Date | Key Features | Status |
|---------|-------------|--------------|--------|
| 2.0.0 | 2025-01-09 | Kyber768 PQC, Enhanced security | ✅ Current |
| 1.1.0 | 2024-12-15 | Optimized performance | 🔄 Legacy support |
| 1.0.0 | 2024-11-01 | Initial release | 🔄 Legacy support |

## Migration Guide

### From v1.1 to v2.0

**Decryption**: No changes needed. v2.0 automatically detects and decrypts v1.1 data.

**Encryption**: Update your code to use the new API:

```kotlin
// Old (v1.1)
val encrypted = BardoQuantumEncryption.encrypt(data, appStrings)

// New (v2.0)
val encrypted = BardoQuantEncryption.encrypt(data)
```

**Configuration**:

```kotlin
// New configuration system
BardoQuantConfig.enableDebugLogging = true
BardoQuantConfig.pbkdf2Iterations = 300000
```

### From v1.0 to v2.0

Same as v1.1 migration. Full backward compatibility maintained.

## Breaking Changes

### v2.0.0

1. **Package name changed**: `com.example.notepad` → `io.github.bardoquant`
2. **Logger interface**: Must use `BardoQuantLogger` instead of Android Log
3. **Configuration**: Use `BardoQuantConfig` object
4. **API simplification**: Removed `AppStrings` parameter

## Security Advisories

No security advisories at this time.

## Credits

### v2.0.0 Contributors
- BardoQuantum Security Team - Core development
- NIST - Post-quantum cryptography standards
- Bouncy Castle Team - Cryptographic libraries
- CRYSTALS-Kyber Team - KEM algorithm

### v1.1.0 Contributors
- BardoQuantum Security Team - Performance optimizations

### v1.0.0 Contributors
- BardoQuantum Security Team - Initial implementation

## Links

- [Repository](https://github.com/yourusername/bardo-quant)
- [Issues](https://github.com/yourusername/bardo-quant/issues)
- [Discussions](https://github.com/yourusername/bardo-quant/discussions)
- [Security Policy](SECURITY.md)
- [Contributing Guide](CONTRIBUTING.md)

## Notes

### About Bardo Notes for People

BardoQuant was originally developed for Bardo Notes for People, a secure note-taking application available on Google Play.

**App History**:
- v1.0 (Nov 2024): Initial release with BardoQuant 1.0
- v1.1 Beta (Dec 2024): Updated to BardoQuant 1.1 with optimizations
- v1.2 Beta (Jan 2025): Updated to BardoQuant 2.0 with post-quantum cryptography

### Open Source Release

January 2025: BardoQuant released as open-source under MIT License to benefit the wider cryptography community and promote post-quantum cryptography adoption.

---

For questions or feedback, please open an issue on GitHub or contact security@bardoquant.io

