# Security Policy

## Supported Versions

We actively support the following versions with security updates:

| Version | Supported          |
| ------- | ------------------ |
| 2.0.x   | :white_check_mark: |
| 1.1.x   | :x:                |
| 1.0.x   | :x:                |

## Reporting a Vulnerability

We take security seriously. If you discover a security vulnerability in BardoQuant, please help us maintain the security of our users by reporting it responsibly.

### How to Report

**Please DO NOT open a public GitHub issue for security vulnerabilities.**

Instead, please report security vulnerabilities by emailing:

**security@bardoquant.io**

### What to Include

Please include the following information in your report:

1. **Description** of the vulnerability
2. **Steps to reproduce** the issue
3. **Potential impact** of the vulnerability
4. **Suggested fix** (if you have one)
5. **Your contact information** for follow-up

### Response Timeline

- **Initial Response**: Within 48 hours
- **Status Update**: Within 7 days
- **Fix Timeline**: Depends on severity
  - Critical: 1-7 days
  - High: 7-30 days
  - Medium: 30-90 days
  - Low: Best effort

### Disclosure Policy

- We will acknowledge your email within 48 hours
- We will provide a detailed response within 7 days
- We will keep you informed about our progress
- We will credit you in the security advisory (unless you prefer to remain anonymous)
- We will coordinate the disclosure timeline with you

### Security Best Practices

When using BardoQuant:

1. **Key Management**
   - Store private keys securely
   - Never commit keys to version control
   - Use environment variables or secure key stores
   - Rotate keys periodically

2. **Dependency Management**
   - Keep all dependencies up to date
   - Regularly check for security advisories
   - Use dependency scanning tools

3. **Production Deployment**
   - Test thoroughly before production use
   - Monitor for unusual patterns
   - Implement proper error handling
   - Use secure random number generation

4. **Data Protection**
   - Validate all input data
   - Implement proper access controls
   - Use secure channels for key exchange
   - Backup encrypted data securely

### Known Security Considerations

#### Quantum-Resistant vs Quantum-Proof

BardoQuant uses CRYSTALS-Kyber768, which is quantum-resistant based on current cryptographic knowledge. However:

- No algorithm can be proven "quantum-proof" indefinitely
- We follow NIST PQC standards and recommendations
- We will update to newer standards as they emerge

#### Key Storage

BardoQuant provides encryption/decryption functionality but does NOT handle key storage. Users are responsible for:

- Secure storage of private keys
- Key backup and recovery
- Key rotation policies
- Access control to keys

#### Side-Channel Attacks

While BardoQuant implements timing attack protection:

- Physical side-channel attacks (power analysis, electromagnetic) are outside our scope
- Users in high-security environments should use additional hardware protection
- Secure execution environments (TEE, HSM) are recommended for critical applications

#### Performance vs Security Trade-offs

BardoQuant prioritizes security over performance:

- PBKDF2 with 300,000 iterations (configurable)
- 16 rounds of SHA-512 for quantum layer
- Multiple encryption layers

Reducing these parameters improves performance but decreases security.

### Security Features

#### Protection Against

- ✅ Quantum computer attacks (Kyber768)
- ✅ Brute-force attacks
- ✅ Timing attacks (constant-time comparison)
- ✅ Known-plaintext attacks
- ✅ Chosen-plaintext attacks
- ✅ Replay attacks (timestamp validation)

#### Additional Security Layers

- Forward secrecy (ephemeral Kyber keys)
- Multiple encryption layers (defense in depth)
- HMAC-SHA512 integrity verification
- Noise injection for traffic analysis resistance
- Decoy checksums for stealth

### Cryptographic Algorithms

All algorithms used are:

- Industry-standard
- Peer-reviewed
- NIST-approved (where applicable)
- Open-source implementations

### Regular Security Audits

We commit to:

- Regular code reviews
- Dependency vulnerability scanning
- Following OWASP guidelines
- Updating to latest security standards
- Community security testing

### Bug Bounty Program

We currently do not have a formal bug bounty program, but we:

- Credit security researchers in release notes
- Respond promptly to security reports
- May offer rewards for critical findings (case-by-case basis)

### Security Updates

Security updates are released as:

- Patch versions (2.0.x) for minor issues
- Minor versions (2.x.0) for significant updates
- Security advisories on GitHub

### Contact

For non-security issues:
- GitHub Issues: https://github.com/yourusername/bardo-quant/issues

For security issues:
- Email: security@bardoquant.io
- PGP Key: [Coming Soon]

### Legal

We comply with responsible disclosure practices and will not take legal action against researchers who:

- Make a good faith effort to avoid privacy violations
- Do not intentionally access or modify user data
- Report vulnerabilities responsibly
- Follow this security policy

Thank you for helping keep BardoQuant and our users safe!

