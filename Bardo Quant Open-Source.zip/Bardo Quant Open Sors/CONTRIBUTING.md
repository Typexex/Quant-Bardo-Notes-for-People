# Contributing to BardoQuant

Thank you for your interest in contributing to BardoQuant! This document provides guidelines and instructions for contributing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Coding Standards](#coding-standards)
- [Pull Request Process](#pull-request-process)
- [Testing Guidelines](#testing-guidelines)
- [Documentation](#documentation)

## Code of Conduct

### Our Pledge

We are committed to providing a welcoming and inclusive environment for all contributors, regardless of:

- Age, body size, disability, ethnicity
- Gender identity and expression
- Level of experience
- Nationality, personal appearance
- Race, religion, or sexual identity

### Expected Behavior

- Be respectful and considerate
- Use welcoming and inclusive language
- Accept constructive criticism gracefully
- Focus on what is best for the community
- Show empathy towards others

### Unacceptable Behavior

- Harassment, trolling, or derogatory comments
- Personal or political attacks
- Public or private harassment
- Publishing private information without permission
- Other conduct inappropriate in a professional setting

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports:

1. **Check existing issues** to avoid duplicates
2. **Test with the latest version** to ensure the bug still exists
3. **Gather information** about your environment

When creating a bug report, include:

- Clear and descriptive title
- Steps to reproduce the issue
- Expected vs actual behavior
- Code samples or test cases
- Environment details (OS, Kotlin version, etc.)
- Stack traces or error messages

Example:

```markdown
**Bug Description**
Brief description of the bug

**To Reproduce**
1. Step one
2. Step two
3. Step three

**Expected Behavior**
What should happen

**Actual Behavior**
What actually happens

**Environment**
- OS: Ubuntu 22.04
- Kotlin: 1.9.20
- BardoQuant: 2.0.0
```

### Suggesting Enhancements

Enhancement suggestions are welcome! Please include:

- Clear description of the enhancement
- Use cases and benefits
- Potential implementation approach
- Any breaking changes

### Security Vulnerabilities

**DO NOT** report security vulnerabilities through public GitHub issues.

Please see [SECURITY.md](SECURITY.md) for responsible disclosure procedures.

### Code Contributions

We welcome:

- Bug fixes
- Performance improvements
- New features
- Documentation improvements
- Test coverage improvements

## Development Setup

### Prerequisites

- JDK 17 or higher
- Kotlin 1.9.20 or higher
- Git
- Gradle (wrapper included)

### Getting Started

1. **Fork the repository**

```bash
# Click "Fork" on GitHub, then clone your fork
git clone https://github.com/yourusername/bardo-quant.git
cd bardo-quant
```

2. **Add upstream remote**

```bash
git remote add upstream https://github.com/originalowner/bardo-quant.git
```

3. **Create a branch**

```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/your-bug-fix
```

4. **Build the project**

```bash
./gradlew build
```

5. **Run tests**

```bash
./gradlew test
```

### Project Structure

```
bardo-quant/
├── src/
│   ├── main/
│   │   └── kotlin/
│   │       └── io/github/bardoquant/
│   │           ├── BardoQuantEncryption.kt
│   │           ├── BardoQuantConfig.kt
│   │           ├── BardoQuantLogger.kt
│   │           └── QuantumCleanResult.kt
│   └── test/
│       └── kotlin/
│           └── io/github/bardoquant/
├── examples/
├── build.gradle.kts
├── README.md
└── ...
```

## Coding Standards

### Kotlin Style Guide

We follow the [Kotlin Coding Conventions](https://kotlinlang.org/docs/coding-conventions.html).

Key points:

- **Indentation**: 4 spaces (no tabs)
- **Line length**: 120 characters maximum
- **Naming**:
  - Classes: PascalCase
  - Functions: camelCase
  - Constants: UPPER_SNAKE_CASE
  - Private members: camelCase with underscore prefix (optional)

### Code Quality

- Write self-documenting code
- Add comments for complex logic
- Use meaningful variable names
- Keep functions small and focused
- Follow SOLID principles
- Avoid premature optimization

### Example

```kotlin
private fun deriveKeyFromSecret(
    secret: ByteArray,
    salt: ByteArray,
    iterations: Int
): ByteArray {
    require(secret.isNotEmpty()) { "Secret cannot be empty" }
    require(salt.size >= 16) { "Salt must be at least 16 bytes" }
    require(iterations > 0) { "Iterations must be positive" }
    
    // Use PBKDF2 for key derivation
    val spec = PBEKeySpec(
        secret.decodeToString().toCharArray(),
        salt,
        iterations,
        256
    )
    
    return SecretKeyFactory
        .getInstance("PBKDF2WithHmacSHA256")
        .generateSecret(spec)
        .encoded
}
```

### Documentation

- All public APIs must have KDoc comments
- Include usage examples for complex features
- Document parameters, return values, and exceptions
- Update README.md for user-facing changes

Example KDoc:

```kotlin
/**
 * Encrypts data using BardoQuantum v2.0 with CRYSTALS-Kyber768.
 *
 * This function provides post-quantum encryption by combining:
 * - Kyber768 KEM for key exchange
 * - AES-256-GCM and ChaCha20 for data encryption
 * - Enhanced quantum-resistant protection layers
 *
 * @param data The plaintext data to encrypt
 * @return Base64-encoded JSON string containing encrypted data
 * @throws SecurityException if encryption fails
 *
 * @sample
 * ```kotlin
 * val encrypted = BardoQuantEncryption.encrypt("sensitive data")
 * println(encrypted)
 * ```
 */
fun encrypt(data: String): String
```

## Pull Request Process

### Before Submitting

1. **Update from upstream**

```bash
git fetch upstream
git rebase upstream/main
```

2. **Run tests**

```bash
./gradlew test
```

3. **Check code style**

```bash
./gradlew ktlintCheck
```

4. **Build successfully**

```bash
./gradlew build
```

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): brief description

Detailed explanation (optional)

Fixes #issue-number
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation only
- `style`: Code style changes
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding tests
- `chore`: Maintenance tasks

Examples:

```bash
feat(encryption): add support for custom PBKDF2 iterations

Allow users to configure PBKDF2 iterations for better
performance/security trade-offs.

Fixes #123
```

```bash
fix(decryption): handle corrupted quantum salt gracefully

Add validation for quantum salt length before decryption
to prevent IndexOutOfBoundsException.

Fixes #456
```

### Submitting the Pull Request

1. **Push your branch**

```bash
git push origin feature/your-feature-name
```

2. **Create pull request** on GitHub

3. **Fill out the template** completely

4. **Link related issues**

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] All tests pass
- [ ] New tests added
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex code
- [ ] Documentation updated
- [ ] No new warnings generated
- [ ] Tests cover changes
```

### Review Process

1. Maintainers will review your PR
2. Address feedback and push updates
3. Once approved, your PR will be merged
4. Your contribution will be credited

### After Merge

1. **Delete your branch**

```bash
git branch -d feature/your-feature-name
git push origin --delete feature/your-feature-name
```

2. **Update your fork**

```bash
git checkout main
git pull upstream main
git push origin main
```

## Testing Guidelines

### Writing Tests

- Write tests for all new features
- Add regression tests for bug fixes
- Aim for >80% code coverage
- Use descriptive test names

### Test Structure

```kotlin
class BardoQuantEncryptionTest {
    @Test
    fun `encrypt should produce valid encrypted output`() {
        // Arrange
        val plaintext = "test data"
        
        // Act
        val encrypted = BardoQuantEncryption.encrypt(plaintext)
        
        // Assert
        assertTrue(BardoQuantEncryption.isEncrypted(encrypted))
        assertTrue(encrypted.contains("bardo_quantum_version"))
    }
    
    @Test
    fun `decrypt should recover original data`() {
        // Arrange
        val original = "test data"
        val encrypted = BardoQuantEncryption.encrypt(original)
        
        // Act
        val result = BardoQuantEncryption.decrypt(encrypted)
        
        // Assert
        assertTrue(result is QuantumCleanResult.Decrypted)
        assertEquals(original, (result as QuantumCleanResult.Decrypted).data)
    }
}
```

### Running Tests

```bash
# Run all tests
./gradlew test

# Run specific test
./gradlew test --tests BardoQuantEncryptionTest

# Run with coverage
./gradlew test jacocoTestReport
```

## Documentation

### README Updates

Update README.md when:

- Adding new features
- Changing public APIs
- Updating dependencies
- Modifying configuration options

### Code Comments

- Explain "why", not "what"
- Document assumptions
- Note limitations
- Reference issues or PRs

### Examples

Provide examples for:

- Common use cases
- Edge cases
- Integration scenarios
- Configuration options

## Questions?

- Open a GitHub Discussion
- Ask in pull request comments
- Email: contribute@bardoquant.io

## Recognition

Contributors are recognized in:

- CHANGELOG.md
- GitHub contributors page
- Release notes (for significant contributions)

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to BardoQuant! Your efforts help make the post-quantum cryptography ecosystem stronger and more accessible.

